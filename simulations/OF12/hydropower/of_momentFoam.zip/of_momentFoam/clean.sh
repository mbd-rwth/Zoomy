#!/usr/bin/env bash
mv 0.orig ic

rm -r  0*
rm -r  1*
rm -r  2*
rm -r  3*
rm -r  4*
rm -r  5*
rm -r  6*
rm -r  7*
rm -r  8*
rm -r  9*
mv ic 0.orig
cp -r 0.orig 0
